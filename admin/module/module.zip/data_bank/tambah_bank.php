
    <div class="main-panel">
                  <div class="content-wrapper">
                  <div class="row">
                  <div class="col-12">
                    <div class="card">
                      <div class="card-body">
                        <h2 class="card-title">Form Tambah Rekening Bank</h2>
                        <hr>
                        
                        <form class="forms-sample" action="../admin/module/data_bank/aksi_simpan.php" method="post">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Nama Bank</label>
                            <input type="text" class="form-control" id="InputNamabank" placeholder="Nama Bank" name="Nama_bank"required>
                          </div>
                          <div class="form-group">
                            <label for="exampleInputPassword1">No rekening</label>
                            <input type="text" class="form-control" id="InputRekening" placeholder="No rekening" name="No_rekening">
                          </div>
                          <button type="submit" class="btn btn-success mr-2">Submit</button>
                          <button class="btn btn-light">Cancel</button>
                        </form>
                      </div>
                    </div>
                  </div> 
                  </div>
                  </div> 